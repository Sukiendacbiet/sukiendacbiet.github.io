<?php
include 'session.php';
$nof = '';
if (isset($_POST['login']) && isset($_POST['username']) && isset($_POST['password'])) {
	if ($_POST['username'] != $tk_admin || $_POST['password'] != $mk_admin) {
		$nof = 'Tài khoản hoặc mật khẩu không đúng !';
	} else {
		$_SESSION['admin'] = 1;
		die(header("Location: /admin.php"));
	}
}
?>


<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Đăng Nhập Admin</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8" />
    <meta name="keywords"
        content="Login Form" />
    <!-- //Meta tag Keywords -->

    <link href="//fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

    <!--/Style-CSS -->
    <link rel="stylesheet" href="admin/style.css" type="text/css" media="all" />
    <!--//Style-CSS -->

    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>

</head>

<body>

    <!-- form section start -->
    <section class="w3l-mockup-form">
        <div class="container">
            <!-- /form -->
            <div class="workinghny-form-grid">
                <div class="main-mockup">
                    <div class="alert-close">
                        <span class="fa fa-close"></span>
                    </div>
                    <div class="w3l_form align-self">
                        <div class="left_grid_info">
                            <img src="admin/image.svg" alt="">
                        </div>
                    </div>
                    <div class="content-wthree">
                        <h2>Đăng Nhập Admin</h2>
                        <p>Trình quản lý web. </p>
	<div class="container mt-4">
		<form method="post">
			<div class="form-group">
				<input type="text" class="form-control" placeholder="Tài khoản admin" required name="username">
			</div>
			<div class="form-group">
				<input type="password" class="form-control" placeholder="Mật khẩu admin" required name="password">
			</div>
			<center><button class="btn btn-primary" type="submit" name="login">Đăng nhập admin</button></center>
		</form>
		<?=$nof?>
	</div>
</body>
</html>