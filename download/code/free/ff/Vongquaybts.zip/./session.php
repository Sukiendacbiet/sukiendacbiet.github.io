<?php
session_start();
$tk_admin = 'admin'; // tài khoản admin
$mk_admin = 'admin'; // mật khẩu admin